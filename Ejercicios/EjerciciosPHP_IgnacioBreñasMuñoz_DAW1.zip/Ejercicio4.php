<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>EJERCICIO 4</title></head>
<body>
<h1>EJERCICIO 4</h1>

<?php
$num = rand(1, 6);
echo "Número aleatorio: $num<br>";
echo "La raiz cuadrada de  $num: " . sqrt($num) . "<br>";
?>

</body>
</html>