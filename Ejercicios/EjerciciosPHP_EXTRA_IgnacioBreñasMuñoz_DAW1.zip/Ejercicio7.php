<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>EJERCICIO 7</title></head>
<body>
<h1>EJERCICIO 7</h1>
<?php
for ($i = 200; $i <= 300; $i += 4) {
    echo "$i<br>";
}
?>
</body>
</html>