<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><title>EJERCICIO 8</title></head>
<body>
<h1>EJERCICIO 8</h1>
<?php
$contador = 0;
$num = 1;
while ($contador < 20) {
    echo "$num<br>";
    $num += 2;
    $contador++;
}
?>
</body>
</html>